
		<footer class="footer" id="footer">
			<div class="row">
				<div class="col-md-12">
					© <?php echo date("Y"); ?> Copyright.
				</div>
			</div>
		</footer>

	</div>
<?php wp_footer(); ?>
 </body>
</html>
