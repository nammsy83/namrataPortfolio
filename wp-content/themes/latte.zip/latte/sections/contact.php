<section class="contact" id="contact">
	<div class="container">
		<div class="row">
			<header class="contact-header" style="visibility: visible; ">
				<h2>Contact</h2>
				<h3>Let's talk.</h3>
			</header>
			<div class="col-lg-12"  data-aos="fade-left">
				<?php echo do_shortcode('[contact-form-7 id="22" title="Contact form 1"]') ?>
			</div>
		</div>
	</div>
</section>