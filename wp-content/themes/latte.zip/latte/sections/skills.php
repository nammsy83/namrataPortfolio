<?php
$latte_skills_title = get_theme_mod('latte_skills_title',__( 'Skills', 'latte' ));
$latte_skills_subtitle = get_theme_mod('latte_skills_subtitle',__( 'Things that I\'m good at.', 'latte' ));
?>

<section class="skills" id="skills">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
			<?php if(!empty($latte_skills_title) || !empty($latte_skills_subtitle)) : ?>
			<header data-sr="ease-in-out wait 0.25s" class="skills-header">
				<?php if(!empty($latte_skills_title)) : ?>
					<h2><?php echo esc_html($latte_skills_title); ?></h2>
				<?php endif; ?>
				<?php if(!empty($latte_skills_subtitle)) : ?>
					<h3><?php echo esc_html($latte_skills_subtitle); ?></h3>
				<?php endif; ?>
			</header>
		<?php endif; ?>
	</div>

</div>
	<div class="row">
		<div class="col-lg-12" data-aos="fade-up">
		<ul class="skills-bar-container">

			<li>
				<div class="progressbar-title">
					<h3>HTML5</h3>
					<span class="percent" id="html-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-html"></span>
				</div>
			</li>
			<li>
				<div class="progressbar-title">
					<h3>CSS / SASS</h3>
					<span class="percent" id="css-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-css"></span>
				</div>
			</li>

			<li>
				<div class="progressbar-title">
					<h3>JavaScript / jQuery</h3>
					<span class="percent" id="javascript-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-javascript"></span>
				</div>
			</li>

			<li>
				<div class="progressbar-title">
					<h3>PHP</h3>
					<span class="percent" id="php-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-php"></span>
				</div>
			</li>

			<li>
				<div class="progressbar-title">
					<h3>AngularJS</h3>
					<span class="percent" id="angular-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-angular"></span>
				</div>
			</li>
			<li>
				<div class="progressbar-title">
					<h3>Wordpress</h3>
					<span class="percent" id="wordpress-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-wordpress"></span>
				</div>
			</li>
			<li>
				<div class="progressbar-title">
					<h3>SEO</h3>
					<span class="percent" id="seo-percent"></span>
				</div>
				<div class="bar-container">
					<span class="progressbar progressgreen" id="progress-seo"></span>
				</div>
			</li>

		</ul>
	</div>
	</div>
</div>
</section>
